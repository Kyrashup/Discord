const express = require('express')
const http = require('http')
const WebSocket = require('ws')

const app = express()
const server = http.createServer(app)
const wss = new WebSocket.Server({ server })

wss.on('connection', ws => {
	ws.on('message', message => {
		// Принимаем сообщение и передаем его всем клиентам
		wss.clients.forEach(client => {
			if (client.readyState === WebSocket.OPEN && client !== ws) {
				client.send(message)
			}
		})
	})
})

server.listen(3000, () => {
	console.log('Сигнальный сервер запущен на порту 3000')
})
